#' @name ELs
#' @title example edge lists for LDnClusteringEL
#' @description NA
#' @docType data
#' @usage ELs
#' @author Petri Kemppainen \email{petrikemppainen2@@gmail.com}
NULL