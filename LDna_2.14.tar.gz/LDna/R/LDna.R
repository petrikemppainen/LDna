#' Linkage disequilibrium network analyses (LDna)
#'
#' Linkage disequilibrium network anlysis (LDna) is an exploratory tool for population genomic data that based on pairwise LD values can be used to identify and extract sets of loci that bear distinct population genetic signals. 
#' 
#' The main pipeline is to produce raw data using: \code{\link{LDnaRaw}}, extract clusters using: \code{\link{extractBranches}}, summerise data using: \code{\link{summaryLDna}} and exploring networks using \code{\link{plotLDnetwork}}.
#' 
#' Since LDna considers all pairwise LD-values in a matrix it is not practical for more than 10-20k SNPs at a time (and need a lot of RAM). LDna can therefore be performed in a nested fashion starting by finding LD-clusters within windows within chromosomes using \code{\link{LDnClusteringEL}}. Edge lists of LD-values need to be provided by the user though.
#' 
#' @author Petri Kemppainen, \email{petrikemppainen2@@gmail.com} and Christopher Knight Christopher Knight, \email{Chris.Knight@@manchester.ac.uk}
#' @docType package
#' @name LDna
NULL