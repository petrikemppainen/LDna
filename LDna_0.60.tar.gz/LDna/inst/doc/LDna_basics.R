## ----setup, include=FALSE------------------------------------------------
library(knitr)

## ---- message=FALSE, eval=FALSE------------------------------------------
#  devtools::install_github("petrikemppainen/LDna")

## ---- message=FALSE, eval=FALSE------------------------------------------
#  install.packages("/path_to/source_file", repos = NULL, type = "source")

## ---- message=FALSE------------------------------------------------------
library(LDna)

## ---- comment=NA, tidy=TRUE----------------------------------------------
LDmat <- structure(c(NA, 0.84, 0.64, 0.24, 0.2, 0.16, 0.44, 0.44, NA, NA, 0.8, 0.28, 0.4, 0.36, 0.36, 0.24, NA, NA, NA, 0.48, 0.32, 0.2, 0.36, 0.2, NA, NA, NA, NA, 0.76, 0.56, 0.6, 0.2, NA, NA, NA, NA, NA, 0.72, 0.68, 0.24, NA, NA, NA, NA, NA, NA, 0.44, 0.24, NA, NA, NA, NA, NA, NA, NA, 0.2, NA, NA, NA, NA, NA, NA, NA, NA), .Dim = c(8L, 8L), .Dimnames = list(paste("L", 1:8, sep=""), paste("L", 1:8, sep="")))

## ---- comment=NA, tidy=TRUE----------------------------------------------
LDmat

## ------------------------------------------------------------------------
ldna <- LDnaRaw(LDmat)

## ---- comment=NA---------------------------------------------------------
ldna$clusterfile

## ---- comment=NA---------------------------------------------------------
ldna$stats

## ----fig.width=10, fig.height=5------------------------------------------
par(mfcol=c(1,2))
clusters1 <- extractClusters(ldna, min.edges = 0, phi = 1)

## ---- comment=NA---------------------------------------------------------
clusters1

## ----fig.width=10, fig.height=5------------------------------------------
par(mfcol=c(1,2))
clusters2 <- extractClusters(ldna, min.edges = 0, phi = 0.25, rm.COCs=FALSE)

## ---- comment=NA---------------------------------------------------------
clusters2

## ---- comment=NA---------------------------------------------------------
summary <- summaryLDna(ldna, clusters2, LDmat)
summary

## ----fig.width=3, fig.height=3-------------------------------------------
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.6)

## ----fig.width=3, fig.height=3-------------------------------------------
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.40)

## ----fig.width=10, fig.height=5------------------------------------------
# Creates a 'weighted' graph object from our lower diagonal LD matrix
g <- graph.adjacency(LDmat, mode="lower", diag=FALSE, weighted=T)
# Removes edges with weights (LD values) below 0.5
g <- delete.edges(g, which(E(g)$weight<=0.5))
# Removes 'unconnected' vertices (loci)
g <- delete.vertices(g, which(degree(g) < 1))
# plots graph, 'edge.label' is used to add the LD values for each edge
plot.igraph(g, edge.label=E(g)$weight)

## ----fig.width=9, fig.height=3-------------------------------------------
par(mfcol=c(1,3))
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters2, summary=summary)

## ----fig.width=9, fig.height=3-------------------------------------------
par(mfcol=c(1,3))
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters2, summary=summary, after.merger=TRUE)

## ---- fig.width=4, fig.height=4, tidy=TRUE-------------------------------
clusters3 <- extractClusters(ldna, min.edges = 0, lambda.lim=0.5, rm.COCs=FALSE)

