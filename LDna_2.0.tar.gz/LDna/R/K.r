#' @name K
#' @title kinship matrix required for emmax example
#' @description NA
#' @docType data
#' @usage K
#' @author Petri Kemppainen \email{petrikemppainen2@@gmail.com}
NULL