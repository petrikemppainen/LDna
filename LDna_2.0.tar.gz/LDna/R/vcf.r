#' @name vcf
#' @title example vcf file for LDnClusteringVCF
#' @description NA
#' @docType data
#' @usage vcf
#' @author Petri Kemppainen \email{petrikemppainen2@@gmail.com}
NULL