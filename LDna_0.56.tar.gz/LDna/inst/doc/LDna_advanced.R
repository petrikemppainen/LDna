
## ----setup, include=FALSE------------------------------------------------
library(knitr)
require(LDna)
data(LDna)


## ------------------------------------------------------------------------
data(LDna)
LDmat <- r2.baimaii_subs
dim(LDmat)


## ----, fig.width=4, fig.height=4, fig.show='hold'------------------------
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.8)
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.5)
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.3)


## ------------------------------------------------------------------------
ldna <- LDnaRaw(LDmat)


## ----, fig.width=4, fig.height=4, fig.show='hold'------------------------
extractClusters(ldna, min.edges = 1, plot.tree = TRUE, extract=FALSE)
extractClusters(ldna, min.edges = 5, plot.tree = TRUE, extract=FALSE)
extractClusters(ldna, min.edges = 18, plot.tree = TRUE, extract=FALSE)


## ----, fig.width=4, fig.height=4, fig.show='hold'------------------------
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.32)
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.30)


## ----, fig.width=5, fig.height=5, comment=NA-----------------------------
clusters <- extractClusters(ldna, min.edges = 10, phi = 5, rm.COCs = F, plot.tree = T, plot.graph = T)


## ----, comment=NA--------------------------------------------------------
summary <- summaryLDna(ldna, clusters, LDmat)
summary


## ----, fig.width=4, fig.height=4, fig.show='hold'------------------------
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters, summary=summary)


## ----, fig.width=4, fig.height=4-----------------------------------------
clusters_4 <- extractClusters(ldna, min.edges = 18, phi = 4, rm.COCs = F, plot.tree = T, plot.graph = T)
clusters_2 <- extractClusters(ldna, min.edges = 18, phi = 2, rm.COCs = F, plot.tree = T, plot.graph = T)


## ----, comment=NA--------------------------------------------------------
summary <- summaryLDna(ldna, clusters_2[c(2,5)], LDmat)
summary


## ----, fig.width=4, fig.height=4, fig.show='hold'------------------------
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters_2[c(2,5)], summary=summary, full.network=F, include.parent=T, after.merger=F)


## ----, fig.width=4, fig.height=4, fig.show='hold'------------------------
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters_2[c(2,5)], summary=summary, full.network=F, include.parent=T, after.merger=T)


## ----, fig.width=4, fig.height=4-----------------------------------------
clusters <- extractClusters(ldna, LDmat, min.edges = 18, lambda.lim=2, rm.COCs = T, plot.tree = F, plot.graph = T)


## ----, fig.width=4, fig.height=4, comment=NA-----------------------------
clusters <- extractClusters(ldna, min.edges=8, phi=2, rm.COCs=TRUE, plot.tree=TRUE, plot.graph=FALSE)
summary <- summaryLDna(ldna, clusters, LDmat)


## ----, fig.width=4, fig.height=4, comment=NA-----------------------------
summary <- summaryLDna(ldna, clusters[c(3,6)], LDmat)
summary


## ----, fig.width=4, fig.height=4, comment=NA-----------------------------
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters[c(3,6)], summary=summary)


## ----, fig.width=4, fig.height=4, comment=NA, fig.show='hold'------------
clusters <- extractClusters(ldna, min.edges = 13, phi=4, rm.COCs = T, plot.tree = T, plot.graph = T)


## ----, comment=NA--------------------------------------------------------
clusters


## ----, fig.width=4, fig.height=4, comment=NA, fig.show='hold'------------
summary <- summaryLDna(ldna, clusters, LDmat)
summary
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters, summary=summary)


