###LDna

Linkage disequilibrium network analyses

Current version is 0.56

## Installing 

With devtools (install from CRAN) LDna can be installed by:

```
devtools::install_github("petrikemppainen/LDna")
```
Development of tutorials is in progress, and documentation is not complete. For the time being, some examples are provided in demo.R. 


