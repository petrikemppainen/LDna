#' @name r2.sim
#' @title List of five r-squared matrices from simulated data
#' @description Simulated data sets. More info to come.
#' @docType data
#' @usage r2.sim
#' @author Petri Kemppainen \email{petrikemppainen2@@gmail.com}
NULL