## ----setup, include=FALSE------------------------------------------------
library(knitr)
library(LDna)

## ------------------------------------------------------------------------
data(LDna)
LDmat <- r2.baimaii_subs

## ----, fig.width=9, fig.height=3, fig.show='hold'------------------------
par(mfcol=c(1,3))
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.8)
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.5)
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.3)

## ------------------------------------------------------------------------
ldna <- LDnaRaw(LDmat)

## ----, fig.width=9, fig.height=3, fig.show='hold'------------------------
par(mfcol=c(1,3))
extractClusters(ldna, min.edges = 1, plot.tree = TRUE, extract=FALSE)
extractClusters(ldna, min.edges = 5, plot.tree = TRUE, extract=FALSE)
extractClusters(ldna, min.edges = 18, plot.tree = TRUE, extract=FALSE)

## ----, fig.width=8, fig.height=4, fig.show='hold'------------------------
par(mfcol=c(1,2))
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.31)
plotLDnetwork(LDmat=LDmat, option=1, threshold=0.30)

## ----fig.width=10, fig.height=5, tidy=TRUE-------------------------------
par(mfcol=c(1,2))
clusters1 <- extractClusters(ldna, min.edges = 18, phi = 4, rm.COCs = FALSE, plot.tree = TRUE, plot.graph = FALSE)

## ----, comment=NA--------------------------------------------------------
summary1 <- summaryLDna(ldna, clusters1, LDmat)
summary1

## ----, fig.width=9, fig.height=6, fig.show='hold'------------------------
par(mfcol=c(2,3))
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters1, summary=summary1)

## ----, fig.width=8, fig.height=4, tidy=TRUE------------------------------
par(mfcol=c(1,2))
clusters_phi2 <- extractClusters(ldna, min.edges = 18, phi = 2, rm.COCs = FALSE, plot.tree = TRUE, plot.graph = TRUE)

## ----, comment=NA, tidy=TRUE---------------------------------------------
summary_phi2 <- summaryLDna(ldna, clusters_phi2[names(clusters_phi2) %in% c("90_0.47","148_0.32")], LDmat)
summary_phi2

## ----, fig.width=8, fig.height=4, fig.show='hold', tidy=TRUE-------------
par(mfcol=c(1,2))
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters_phi2[names(clusters_phi2) %in% c("90_0.47","148_0.32")], summary=summary_phi2, full.network=FALSE, include.parent=TRUE, after.merger=FALSE)

## ----, fig.width=8, fig.height=4, fig.show='hold', tidy=TRUE-------------
par(mfcol=c(1,2))
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters_phi2[names(clusters_phi2) %in% c("90_0.47","148_0.32")], summary=summary_phi2, full.network=FALSE, include.parent=TRUE, after.merger=TRUE)

## ----, fig.width=4, fig.height=4, comment=NA, tidy=TRUE------------------
clusters2 <- extractClusters(ldna, min.edges=8, phi=2, rm.COCs=TRUE, plot.tree=TRUE, plot.graph=FALSE)

## ----, fig.width=4, fig.height=4, comment=NA, tidy=TRUE------------------
clusters2$"194_0.21"

## ----, fig.width=8, fig.height=4, comment=NA-----------------------------
par(mfcol=c(1,2))
summary2 <- summaryLDna(ldna, clusters=clusters2[names(clusters2) %in% c("118_0.38","194_0.21")], LDmat)
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters2[names(clusters2) %in% c("118_0.38","194_0.21")], summary=summary2)

## ----, fig.width=10, fig.height=5, comment=NA, fig.show='hold', tidy=TRUE----
par(mfcol=c(1,2))
clusters_final <- extractClusters(ldna, min.edges = 18, phi=4)

## ----, comment=NA--------------------------------------------------------
clusters_final

## ----, fig.width=8, fig.height=8, comment=NA, fig.show='hold'------------
summary_final <- summaryLDna(ldna, clusters_final, LDmat)
summary_final
par(mfcol=c(2,2))
plotLDnetwork(ldna, LDmat, option=2, clusters=clusters_final, summary=summary_final)

